//
//  QRCodeReader.h
//  QRCodeReader
//
//  Created by Yannick LORIOT on 17/09/15.
//  Copyright © 2015 Yannick Loriot. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QRCodeReader.
FOUNDATION_EXPORT double QRCodeReaderVersionNumber;

//! Project version string for QRCodeReader.
FOUNDATION_EXPORT const unsigned char QRCodeReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QRCodeReader/PublicHeader.h>


