//
//  TiQrcode.h
//  titanium-qrcode
//
//  Created by Hans Knoechel
//  Copyright (c) 2020 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiQrcode.
FOUNDATION_EXPORT double TiQrcodeVersionNumber;

//! Project version string for TiQrcode.
FOUNDATION_EXPORT const unsigned char TiQrcodeVersionString[];

#import "TiQrcodeModuleAssets.h"
